# `a11y input`

#### `has a static shadowDom`

```html
<slot name="label">
</slot>
<slot name="input">
</slot>
```

